import React from 'react';
import { Navbar, Nav, Container, Button, NavDropdown } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Footer.css';
import logo from './images/logonew.png';
import { Link as ScrollLink } from 'react-scroll';
import Logout from './Logout';
import { Link, useParams } from 'react-router-dom';
import { FaUserCircle } from 'react-icons/fa';

export const LandingHeader = () => {
  return (
    <header>
    <Navbar style={{ backgroundColor: '#60a5fa' }} variant="light" expand="lg" className="py-2 custom-navbar">
      <Container>
        {/* Logo and Brand on the left */}
        <Navbar.Brand href="/">
          <img
            src={logo}
            width="80"
            height="80"
            className="d-inline-block align-top"
            alt="AB logo"
          />{' '}
          <span className="brand-name">ABessets</span> {/* Custom font style */}
        </Navbar.Brand>
  
        {/* Links aligned to the right */}
        <Nav className="me-auto d-flex align-items-center">
        <ScrollLink to="aboutSection" 
            smooth={true}
            duration={500}
            className="nav-link-custom text-white">
            About
          </ScrollLink>
          &nbsp; &nbsp;
          <ScrollLink to="contactSection"
             smooth={true}
             duration={500}
            className="nav-link-custom text-white">
            Contact-Us
          </ScrollLink>
        </Nav>
  
        {/* Collapse Menu Toggle for Mobile View */}
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
  
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto d-flex align-items-center">
            {/* Logout Button aligned to the left */}
            <NavDropdown 
              title={<FaUserCircle size={40} />} 
              id="navbarScrollingDropdown"
              align="end"
            >
          <NavDropdown.Item  id="navbarScrollingDropdown"><Logout/></NavDropdown.Item>
          </NavDropdown>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  </header>
  
  );
};

