import React from 'react'
import './About.css'
import asset from './images/assets.png'


export const About = () => {
  return (
    <div className='about-page'>
        <header className='mt-2'>
            <div className='container h-100 d-flex align-items-center justify-content-center'>
                <h1 className='text-light'>About</h1>

            </div>

        </header>
        <div className='container my-5 '>
           <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Debitis exercitationem saepe quibusdam nemo, consectetur fugiat vel repellendus culpa aliquam quis cum aperiam magni in, rem incidunt nostrum accusantium commodi sunt fugit nam ex placeat voluptas voluptatibus! Quibusdam magni inventore dicta vero, recusandae reiciendis fugit cupiditate harum sed possimus nobis modi.</p>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Excepturi nulla perspiciatis repellendus dolores adipisci exercitationem ullam amet illum in placeat pariatur facere eum doloremque et blanditiis nihil incidunt, deserunt suscipit asperiores quibusdam voluptate. Doloremque, ducimus! Itaque obcaecati, ipsam quidem vero nesciunt alias ex aperiam nihil dolorum, magni amet mollitia aspernatur.</p>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Facilis vel, obcaecati ad esse aliquam nam praesentium quidem odit amet temporibus possimus, eius repellat assumenda, reprehenderit sit asperiores ipsa harum soluta quos doloremque consequuntur ex molestiae quia sunt! Nobis, magni laboriosam quia autem ipsum non, cum modi accusamus est facilis veritatis!</p>
        </div>

    </div>
  )
}
