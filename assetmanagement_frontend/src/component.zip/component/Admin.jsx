import React from 'react'
import { Button, Row } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import './Admin.css'

export const Admin = () => {
  return (
    <div className='Admin-page'>
    <header className='h-70 min-vh-100 d-flex justify-content-center align-items-center text-light shadow'>
        <div className='row'>
          <div className='col-12 d-flex flex-column align-items-center text-center'>
            <h1 className='mb-0 text-black fw-bold'>Welcome Admin</h1>
            <br/>
            <div className="d-flex align-items-center">
              <Link to="/assets/:username">
                <Button type='button' className='btn btn-primary btn-lg'>Asset related
                  information
                </Button>
              </Link> &nbsp; &nbsp; &nbsp; &nbsp;
              <Link to="/audits">
                <Button type='button' className='btn btn-primary btn-lg'>Audit</Button>
              </Link> &nbsp; &nbsp; &nbsp; &nbsp;
              <Link to="/service-requests">
                <Button type='button' className='btn btn-primary btn-lg'>Service Request validation</Button>
              </Link>
            </div>
            <br/>
            <div className="d-flex justify-content-center">
              <Link to="/employees">
                <Button type='button' className='btn btn-primary btn-lg'>Employee information</Button>
              </Link> &nbsp; &nbsp;&nbsp; &nbsp;
              <Link to="/asset-allocations">
                <Button type='button' className='btn btn-primary btn-lg'>Asset Allocation</Button>
              </Link> 
            </div>
          </div>
        </div>
      </header>
      </div>
  )
}
