import React from 'react'
import './LandingPage.css'

const Error = () => {
  return (
    <div className='InvalidPage'>
        <header className='h-80 min-vh-100 d-flex justify-content-center align-items-center text-light shadow'>
        <div className='row'>
          <div className='col-10 d-flex flex-column align-items-center text-center'>
            <div className="d-flex align-items-center">
            </div>
          </div>
        </div>
      </header>

    </div>
  )
}

export default Error