
import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import AssetService from '../services/AssetService';
import { useAuth } from '../context/useAuth';
import { Button } from 'react-bootstrap';

const DisplayAssets = () => {
  const [assets, setAssets] = useState([]);
  const { auth } = useAuth();
  const [error, setError] = React.useState("")
  const errorRef = useRef()
  const token = auth.token;

  useEffect(() => {
    AssetService.findAllAssets(token)
      .then((response) => {
        console.log('API Response:', response.data);
        setAssets(response.data);
      })
      .catch((error) => {
        console.error('Error fetching assets:', error);
        setError("Error fetching assets")
      });
  }, []);

  const handleDelete = (id) => {
    AssetService.deleteByAssetId(id, token).then(() => {
      setAssets(assets.filter(asset => asset.assetID !== id));
    }).catch((error)=>{
      if(error.response?.status===403){
           console.log("error 403 occured")
          setError("You cannot delete the assets")
      }
      else{
          setError("No Server Response")
      }
  })
  };

  return (
    <div className="container">
      <h2 className="text-center">Assets</h2>
      <p ref={errorRef} className={error?'errmsg':'offscreen'}
                aria-live='assertive'>{error}
            </p>
      <div className="text-center mb-2">
        <Link to="/add-asset" className="btn btn-primary mb-2">Add Asset</Link>
      </div>
      <table className="table table-bordered table-striped">
        <thead className="thead-dark">
          <tr>
            <th>Asset ID</th>
            <th>Asset Name</th>
            <th>Asset Category</th>
            <th>Asset Model</th>
            <th>Asset Value</th>
            <th>Manufacturing Date</th>
            <th>Expiry Date</th>
            <th>Status</th>
            <th>Asset Request</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {assets.length === 0 ? (
            <tr>
              <td colSpan="6" className="text-center">No assets available.</td>
            </tr>
          ) : (
            assets.map(asset => (
              <tr key={asset.assetID}>
                <td>{asset.assetID}</td>
                <td>{asset.assetName}</td>
                <td>{asset.assetCategory}</td>
                <td>{asset.assetModel}</td>
                <td>{asset.assetValue}</td>
                <td>{asset.manufacturingDate}</td>
                <td>{asset.expiryDate}</td>
                <td>{asset.status}</td>
                <td>
                  <Link to={`/add-service-request?assetId=${asset.assetID}`}>
                    <Button type='button' className='btn btn-primary btn-sm' >Request</Button>
                  </Link>
                </td>
                <td>
                  <Link to={`/edit-asset/${asset.assetID}`} className="btn btn-info btn-sm">Edit</Link>  &nbsp;
                  <button onClick={() => handleDelete(asset.assetID)} className="btn btn-danger btn-sm ml-2">Delete</button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default DisplayAssets;
